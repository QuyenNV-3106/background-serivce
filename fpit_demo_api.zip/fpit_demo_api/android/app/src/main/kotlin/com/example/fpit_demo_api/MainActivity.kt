package com.example.fpit_demo_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
